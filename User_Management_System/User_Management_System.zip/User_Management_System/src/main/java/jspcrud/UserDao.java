/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jspcrud;

/**
 *
 * @author jiten
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
public static Connection getConnection(){
	Connection con=null;
	try{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/coursework?serverTimezone=UTC","root","");
	}catch(ClassNotFoundException | SQLException e){System.out.println(e);}
	return con;
}
public static int save(User u) {
	int status=0;
        
	try{
                Connection con = getConnection();
		PreparedStatement ps=con.prepareStatement("insert into users(Admin,Firstname,Lastname,Gender,Phonenumber,Username,Email,Password) values(?,?,?,?,?,?,?,?)");
		ps.setString(1, u.getAdmin());
                ps.setString(2, u.getFirstName());
                ps.setString(3, u.getLastName());
		ps.setString(4, u.getGender());
                ps.setString(5, u.getPhonenumber());
                ps.setString(6, u.getUsername());
                ps.setString(7, u.getEmail());
                ps.setString(8, u.getPassword());
		
		status=ps.executeUpdate();
               
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static List<User> getAllRecords(){
	List<User> list=new ArrayList<User>();
	
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("select * from users");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			User u=new User();
                        u.setAdmin(rs.getString("Admin"));
			u.setFirstname(rs.getString("Firstname"));
                        u.setLastname(rs.getString("Lastname"));
			u.setPassword(rs.getString("Password"));
			u.setEmail(rs.getString("Email"));
			u.setGender(rs.getString("Gender"));
			u.setUsername(rs.getString("Username"));
                        u.setPhonenumber(rs.getString("phonenumber"));
			list.add(u);
		}
	}catch(Exception e){System.out.println(e);}
	return list;
}
public static User getRecordByUsername(String Username){
	User u=null;
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("select * from users where Username=?");
		ps.setString(1,Username);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			u=new User();
			u.setAdmin(rs.getString("admin"));
			u.setFirstname(rs.getString("first name"));
                        u.setLastname(rs.getString("Last name"));
			u.setPassword(rs.getString("password"));
			u.setEmail(rs.getString("email"));
			u.setGender(rs.getString("Gender"));
			u.setUsername(rs.getString("Username"));
                        u.setPhonenumber(rs.getString("Phonenumber"));
		}
	}catch(Exception e){System.out.println(e);}
	return u;
}





}
